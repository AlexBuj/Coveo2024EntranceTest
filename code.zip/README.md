Ce repo contient le test pour l'inscription au Coveo Blitz 2024.
